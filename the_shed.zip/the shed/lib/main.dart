import 'package:curved_navigation_bar/curved_navigation_bar.dart';
import 'package:flutter/material.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'ToolShed',
      home: MyHomePage(),
    );
  }
}

class MyHomePage extends StatefulWidget {
  @override
  _MyHomePageState createState() => _MyHomePageState();
}
class _MyHomePageState extends State<MyHomePage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          backgroundColor: Colors.black,
          title: Image.asset("assets/logo.png",
            width: 120,
          ),
          actions: <Widget>[
            IconButton(
              icon: const Icon(Icons.near_me, color: Colors.grey,),
            )
          ],
        ),
        body: Container(
          color: Color.fromRGBO(41, 41, 41, 1),
          height: MediaQuery.of(context).size.height,
          width: MediaQuery.of(context).size.width,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              Text(
                'NEEDS TO ADD BODY',
                style: TextStyle(
                color: Color.fromRGBO(255, 163, 26, 1)
                ),
              )
            ],
          )
        ),

        bottomNavigationBar: CurvedNavigationBar(
          backgroundColor: Color.fromRGBO(41, 41, 41, 1),
          color: Color.fromRGBO(128, 128, 128, 1),
          height: 60,
          animationDuration: Duration(milliseconds: 1000),
          index: 3,
          animationCurve: Curves.fastLinearToSlowEaseIn,
          items: <Widget>[
            Icon(Icons.home, size: 30, color: Colors.black),
            Icon(Icons.search, size: 30, color: Colors.black),
            Icon(Icons.favorite_border, size: 30, color: Colors.black,),
            Icon(Icons.person, size: 30, color: Colors.black),
          ],
        ),
      );
  }
}

